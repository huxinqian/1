import UIKit
import Foundation

//作业一 闭包排序
var primes = [Int]()
for i in 2...10000{
    var isPrime = true
    for j in 2..<i{
        if i%j == 0{
            isPrime = false
        }
    }
    if isPrime{
        primes.append(i)
    }
}

//first method
func compare(x:Int,y:Int) -> Bool{
    return x > y
}
primes.sort(by:compare)
print(primes)

//second method 标准闭包语法，指定参数名和类型
primes.sort{(x:Int,y:Int)->Bool in
    return x > y
}
print(primes)

//third method  省略参数类型
primes.sort{(x,y)->Bool in
    return x > y
}
print(primes)

//fourth method  $0代表第一个参数，$1代表第二个参数
primes.sort{$0>$1}
print(primes)

//fifth method
primes.sort(by:>)
print(primes)



//作业二 类的属性和方法
enum Gender: Int {//性别枚举
    case male
    case female
}
class Person: CustomStringConvertible{//定义Person类
    var firstName: String
    var lastName: String
    var age: Int
    var gender: Gender
    var fullName: String {
        return firstName + lastName
    }
    //构造方法
    init(firstName: String, lastName: String, age: Int, gender: Gender){
        self.firstName = firstName
        self.lastName = lastName
        self.age = age
        self.gender = gender
    }
    //便利构造函数
    convenience init(firstName: String, age: Int, gender: Gender){
        self.init(firstName: firstName, lastName: "", age: age, gender: gender)
    }
    
    convenience init(firstName: String){
        self.init(firstName: firstName, age: 20, gender: Gender.male)
    }
    //重载==
    static func ==(p1: Person, p2: Person) -> Bool{
        return p1.fullName == p2.fullName && p1.age == p2.age && p1.gender == p2.gender
    }
    //重载!=
    static func !=(p1: Person, p2: Person) -> Bool{
        return !(p1 == p2)
    }
    //使用print直接输出对象内容
    var description: String{
        return "fullName: \(self.fullName), age: \(self.age), gender: \(self.gender)"
    }
}

var p1 = Person(firstName: "hu")
var p2 = Person(firstName: "hu", age: 18, gender: .male)
print(p1)
print(p2)
print(p1 == p2)  //输出false
print(p1 != p2)  //输出true

class Teacher : Person{
    var title:String
    //构造方法
    init(title: String, firstName: String, lastName: String, age: Int, gender: Gender){
        self.title = title
        super.init(firstName: firstName, lastName: lastName, age: age, gender: gender)
    }
    init(title: String) {
        self.title = title
        super.init(firstName: "", lastName: "", age: 20, gender: .male)
    }
    //重写父类的计算属性
    override var description: String {
        return "title: \(self.title), fullName: \(self.fullName), age: \(self.age), gender: \(self.gender)"
    }
}

let t1 = Teacher(title: "hello")
print(t1)

//学生类
class Student: Person {
    var stuNo: Int  //学号
    //构造方法
    init(stuNo: Int, firstName: String, lastName: String, age: Int, gender: Gender) {
        self.stuNo = stuNo
        super.init(firstName: firstName, lastName: lastName, age: age, gender: gender)
    }
    init(stuNo: Int) {
        self.stuNo = stuNo
        super.init(firstName: "", lastName: "", age: 20, gender: Gender.male)
    }
    //重写父类的计算属性
    override var description: String {
        return "stuNo: \(self.stuNo), fullName: \(self.fullName), age: \(self.age), gender: \(self.gender)"
    }
}
let s1 = Student(stuNo: 2015110101)
print(s1)


var arr = [Person]()
for i in 1...4 {//生成4个Person对象
    let person = Person(firstName: "li", lastName: "\(i)", age: 40, gender: .male)
    arr.append(person)
}

for i in 1...3 {//生成3个Teacher对象
    let teacher = Teacher(title: "hello", firstName: "zhang", lastName: "\(i)", age: 36, gender: .female)
    arr.append(teacher)
}

for i in 1...3 {//生成3个Student对象
    let student = Student(stuNo: 2015110100 + i, firstName: "chen", lastName: "\(i)", age: 18, gender: .male)
    arr.append(student)
}

//定义一个字典，用于统计每个类的对象个数
var dict = ["Person": 0, "Teacher": 0, "Student": 0]
for item in arr {
    if item is Teacher {
        dict["Teacher"]! += 1
    } else if item is Student {
        dict["Student"]! += 1
    } else {
        dict["Person"]! += 1
    }
}
//输出字典值
for (key, value) in dict {
    print("\(key) has \(value) items")
}


//根据age从大到小排序
arr.sort { return $0.age > $1.age}
for item in arr {
    print(item)
}

//根据全名从前往后排序
arr.sort { return $0.fullName < $1.fullName}
for item in arr {
    print(item)
}

//根据gender和age从大往小排序
arr.sort { return ($0.gender.rawValue > $1.gender.rawValue) && ($0.age > $1.age) }
for item in arr {
    print(item)
}
